import {
    initializeApp,
    getAuth,
    signInWithEmailAndPassword,
    getFirestore,
    collection,
    query,
    where,
    getDocs,
    app,
    db,
    setDoc,
    doc,
    getDoc,
    updateDoc
} from "./config.js"



/* Adding Dynmic Inputs For Area List */
var i = 1;
$("#add_ingr_tr").click(() => {
    i++;
    $(".dynamic_fields_tr").append("<tr id='row" + i + "'><td><div class='addMore_ingr d-flex align-items-center'><input type='text' id='carBrand' class='form-control mr-2' placeholder='Car Brand' required> <div><i onclick='' id='" + i + "' class='p-1 m-3 mx-2 fas fa-times " + i + " rm_ingr_tr btn_remove_ingr'></i></div></div></td></tr>");
});


$(document).on("click", ".btn_remove_ingr", function () {
    var button_id = $(this).attr('id');
    $("#row" + button_id + "").remove();
});



var addNewCars = document.getElementById("addNewCars")

/* Add Car Funtion */
function addCars(action, cars, carType, transportName) {
    addNewCars.innerText = "Add";


    console.log(carType, "i am car type");

    carType = carType.toLowerCase();
    transportName = transportName.toLowerCase();

    /* Creating car list */
    var carList = [...cars].map(input => input.value !== undefined && input.value);
    carList = carList.filter(el => el != "");

    /* Creating Object */
    var key = carType;
    var obj = {};
    obj[key] = {
        carBrand: carList,
        carCompany: carType,
        status: true,
        timestamp: Date.now()
    }

    /* Setting Car Object In Firebase */
    function setCarDoc(transportName, obj, showMsg) {
        transportName = transportName.toLowerCase();
        setDoc(doc(db, "transport", transportName),
            obj, {
                merge: true
            }
        ).then(msg => {
            if (msg === undefined) {
                document.getElementById("customRow").innerHTML = "<h1></h1>";
                document.getElementById("carMsg").innerHTML = `<p class="success-msg">${showMsg}</p>`;
                document.getElementById("carForm").reset();
                setTimeout(() => {
                    document.getElementById("carMsg").innerHTML = '';
                    // location.reload();
                }, 2000);
            }
        })
    }



    /* Get & Set Cars Function */
    async function getCars() {
        /* Get Data From Firebase  */
        const docRef = doc(db, "transport", transportName);
        const docSnap = await getDoc(docRef);
        var carObj = docSnap.data();


        /* Car Name Array */
        var companyName = [];
        companyName = carObj ? Object.keys(carObj) : [];



        if (action == "add") {

            /* Check If array contain car type */
            if (companyName.includes(carType)) {
                /* Confirm to over write or cancel */
                if (confirm("Transport already exist. \n Do you want to over write?")) {
                    console.log(transportName, obj, "Car Collection Over Written message");
                    setCarDoc(transportName, obj, "Car Collection Over Written");
                } else {
                    document.getElementById("carForm").reset();
                }
            } else {
                document.getElementById("carForm").reset();
            }
        } else {
            /* if action is update so simply update */
            setCarDoc(transportName, obj, "Car Collection Updated");
            document.getElementById("carForm").reset();
            addNewCars.value = "add";

            addCarCollection();


        }


    }


    /* Calling Get And Set Car Funtion */
    getCars();

}


if(addNewCars){
    
addNewCars.addEventListener("click", () => {
    var cars = document.querySelectorAll("#carBrand");
    var carType = document.getElementById("carType").value;
    var transportName = document.getElementById("transportName").value;
    var addNewCarsValue = document.getElementById("addNewCars").value;
    addCars(addNewCarsValue, cars, carType, transportName);
});

}


/* Add Car Collection IN html page */
function addCarCollection() {

    /* firebase query */
    getDocs(collection(db, "transport"))
        .then((querySnapshot) => {

            var newCarCollection = querySnapshot.docs
                .map((doc) => ({
                    ...doc.data(),
                    id: doc.id
                }));


            console.log(newCarCollection);

            var carRows = "";
            var num = 1;
            newCarCollection.map(car => {

                var companyType = Object.values(car)[Object.values(car).length - 1];
                /* Delete last element from object which is id */
                delete car["id"];

                var carCollection = Object.values(car);

                carCollection.map(carObj => {

                    /* Date Setting */
                    var date = new Date(carObj.timestamp);
                    date = `${date.getDate()}/${date.getMonth()}/${date.getFullYear()}`

                    /* combining carBrand array with ,  */
                    var carBrandStr = (carObj.carBrand).join(", <br>");

                    carBrandStr = carBrandStr.toUpperCase();

                    /* table row html for car collection  */
                    console.log(carBrandStr);
                    carRows += `<tr>
                <td>${num}</td>
                <td>${(companyType).toUpperCase()}</td>
                <td>${(carObj.carCompany).toUpperCase()}</td>
                <td>${carBrandStr}</td>
                <td>${date}</td>
                <td>${carObj.status == true ? "Approved": "Pending"}</td>
                <td class="align-middle text-center ">
                <button onClick="showUpdate(this)" value="${companyType},${carObj.carCompany},${carObj.status}" class='btn btn-sm p-2 
                btn-${carObj.status == true ? "danger" :"success" }'>
                ${carObj.status == true ? "Disable" : "Enable" }
                </button>
              </td>
              <td class="align-middle text-center ">
              <button onClick="editCar(this)" value="${companyType},${carObj.carCompany}" class='btn btn-sm p-2 
              btn-info'>
              Edit
              </button>
              </td>

       

                </tr>`;
                    // console.log(carRows);
                    num += 1;
                });
            })
            document.getElementById("carCollections").innerHTML = carRows;

            // document.getElementById("carCard").innerHTML =  "<h1>life is good</h1>";

        })
        .catch((err) => {

            // TODO: Handle errors
            console.error("Failed to retrieve data", err);
        });



}

export {
    addCarCollection,
    addCars
};


/* On Load Window show Car Collection data */
window.onload = async () => {
    addCarCollection();
};






// async function updateCarStatus(transportName, carType, status) {

//     /* Ref */
//     const docRef = doc(db, "transport", transportName);

//     const docSnap = await getDoc(docRef);
//     var carArrayCollection = docSnap.data();

//     /* Getting Object For Update */
//     var carArray = carArrayCollection[carType];

//     /* Change status */
//     carArray["status"] = status;

//     /* Setting Dynamic key of object */
//     var key = carType;
//     var obj = {};
//     obj[key] = carArray;

//     /* Update Object */
//     updateDoc(docRef, {
//         honda: carArray
//     }).then(res => console.log(res));
// }


// updateCarStatus("sedan", "honda", true);