import {
    initializeApp,
    getAuth,
    signInWithEmailAndPassword,
    getFirestore,
    collection,
    query,
    where,
    getDocs,
    app,
    db,
    setDoc,
    doc,
    getDoc,
    updateDoc
} from "./config.js"

var getReportedUsers = async (uid) => {
    // console.log(uid, "i am uid");
    const docRef = await doc(db, "users", uid);
    const docSnap = await getDoc(docRef);
    var user = docSnap.data();
    // console.log("i am call from get reported user function");
    // console.log(user);
    return user;
}





async function getAllReports() {
    // const q = query(collection(db, "report"));
    // const querySnapshot = await getDocs(q);

    // const docRef = doc(db, "report");
    // const docSnap = await getDoc(docRef);
    // var reportsCollection = docSnap.data();
    // console.log(reportsCollection);


    const querySnapshot = await getDocs(collection(db, "report"));
    var reportListRow = "";
    var reportListArray = [];
    querySnapshot.forEach(async (r) => {
        var report = r.data();

        var reportedTo = await getReportedUsers(report.reportedTo);
        var reportedBy = await getReportedUsers(report.reportedBy);
        reportListRow += "life";
        var row = `<tr>
                        <td>1</td>
                        <td ">
                            <p class="text-xs font-weight-bold  text-justify  mb-0  ">${report.description}</p>
                        </td>
                        <td class="text-center">
                            <div class="d-flex   flex-column align-items-center w-100">
                                <img src="${reportedBy?.photo || './assets/img/avatar.png'}" style="clip-path:circle()" class="w-25 h-25" alt="">
                                <small class="mt-1 text-bold w-100 " style="font-size:10px;">${(reportedBy.name).toUpperCase()}</small>
                            </div>
                        </td>
                        <td class="text-center"> 
                            <div class="d-flex  flex-column align-items-center w-100">
                                <img src="${reportedTo?.photo || './assets/img/avatar.png'}" style="clip-path:circle()" class="w-25 h-25" alt="">
                                <small class="mt-1 text-bold w-100 " style="font-size:10px;">${(reportedTo.name).toUpperCase()}</small>
                            </div>
                        </td>
                        <td class="align-middle text-center ">
                            <button class='btn btn-xm p-2  bg-gradient-danger style="margin-bottom:-0px'>Deactive</button>
                        </td>
                        <td class="align-middle text-center ">
                            <button class='btn btn-xm p-2  bg-gradient-danger style="margin-bottom:-0px'>Delete</button>
                        </td>
                    </tr>`;
        document.getElementById("reportCollection").innerHTML += row;
    });
}

window.onload = getAllReports();