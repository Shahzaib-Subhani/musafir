$(document).ready(function () {
    setTimeout(() => {
        $('#usersTable').DataTable();
    }, 1000);
})